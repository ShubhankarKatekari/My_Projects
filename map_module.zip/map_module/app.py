from flask import Flask, request, render_template, jsonify
import json
from datetime import datetime, timedelta
import heapq

app = Flask(__name__)

# In-memory storage of schedules
transit_data = {
  "lines": [
    {
      "id": "Line-Blue",
      "name": "Blue Line",
      "stops": ["Downtown", "Riverside", "SanMarco", "Beaches", "JaxAirport"],
      "schedule": {
        "weekday": {
          "Downtown":  ["00:00","01:00","02:00","03:00","04:00","05:00","06:00","07:00","08:00","09:00","10:00","11:00",
                        "12:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00","23:00"],
          "Riverside": ["00:00","01:00","02:00","03:00","04:00","05:00","06:00","07:00","08:00","09:00","10:00","11:00",
                        "12:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00","23:00"],
          "SanMarco":  ["00:00","01:00","02:00","03:00","04:00","05:00","06:00","07:00","08:00","09:00","10:00","11:00",
                        "12:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00","23:00"],
          "Beaches":   ["00:00","01:00","02:00","03:00","04:00","05:00","06:00","07:00","08:00","09:00","10:00","11:00",
                        "12:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00","23:00"],
          "JaxAirport":["00:00","01:00","02:00","03:00","04:00","05:00","06:00","07:00","08:00","09:00","10:00","11:00",
                        "12:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00","23:00"]
        }
      }
    },
    {
      "id": "Line-Red",
      "name": "Red Line",
      "stops": ["Westside", "Downtown", "Arlington", "Southside", "Beaches"],
      "schedule": {
        "weekday": {
          "Westside":  ["00:00","01:00","02:00","03:00","04:00","05:00","06:00","07:00","08:00","09:00","10:00","11:00",
                        "12:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00","23:00"],
          "Downtown":  ["00:00","01:00","02:00","03:00","04:00","05:00","06:00","07:00","08:00","09:00","10:00","11:00",
                        "12:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00","23:00"],
          "Arlington": ["00:00","01:00","02:00","03:00","04:00","05:00","06:00","07:00","08:00","09:00","10:00","11:00",
                        "12:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00","23:00"],
          "Southside": ["00:00","01:00","02:00","03:00","04:00","05:00","06:00","07:00","08:00","09:00","10:00","11:00",
                        "12:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00","23:00"],
          "Beaches":   ["00:00","01:00","02:00","03:00","04:00","05:00","06:00","07:00","08:00","09:00","10:00","11:00",
                        "12:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00","23:00"]
        }
      }
    },
    {
      "id": "Line-Green",
      "name": "Green Line",
      "stops": ["Mandarin", "SanMarco", "Downtown", "Northside"],
      "schedule": {
        "weekday": {
          "Mandarin":  ["00:00","01:00","02:00","03:00","04:00","05:00","06:00","07:00","08:00","09:00","10:00","11:00",
                        "12:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00","23:00"],
          "SanMarco":  ["00:00","01:00","02:00","03:00","04:00","05:00","06:00","07:00","08:00","09:00","10:00","11:00",
                        "12:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00","23:00"],
          "Downtown":  ["00:00","01:00","02:00","03:00","04:00","05:00","06:00","07:00","08:00","09:00","10:00","11:00",
                        "12:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00","23:00"],
          "Northside": ["00:00","01:00","02:00","03:00","04:00","05:00","06:00","07:00","08:00","09:00","10:00","11:00",
                        "12:00","13:00","14:00","15:00","16:00","17:00","18:00","19:00","20:00","21:00","22:00","23:00"]
        }
      }
    }
  ]
}

# Stop locations with approximate coordinates
stop_locations = {
    "Downtown":  {"lat": 30.3322, "lng": -81.6557},
    "Riverside": {"lat": 30.3080, "lng": -81.6790},
    "SanMarco":  {"lat": 30.3003, "lng": -81.6529},
    "Beaches":   {"lat": 30.2858, "lng": -81.3895},
    "JaxAirport":{"lat": 30.4941, "lng": -81.6879},
    "Westside":  {"lat": 30.2850, "lng": -81.7526},
    "Arlington": {"lat": 30.3433, "lng": -81.5934},
    "Southside": {"lat": 30.2340, "lng": -81.5804},
    "Mandarin":  {"lat": 30.1549, "lng": -81.6300},
    "Northside": {"lat": 30.4400, "lng": -81.6600}
}

graph = {}

def build_graph_from_data():
    global transit_data, graph
    graph.clear()
    for line in transit_data["lines"]:
        stops = line["stops"]
        # Assume a fixed travel time of 10 minutes between consecutive stops
        for i in range(len(stops)-1):
            graph.setdefault(stops[i], []).append((stops[i+1], line["id"], 10))
            graph.setdefault(stops[i+1], []).append((stops[i], line["id"], 10))

build_graph_from_data()

def get_next_departure_time(line_id, stop, current_time):
    for line in transit_data["lines"]:
        if line["id"] == line_id:
            times = line["schedule"]["weekday"].get(stop, [])
            possible_times = [datetime.combine(current_time.date(), datetime.strptime(t, "%H:%M").time()) for t in times]
            for t in possible_times:
                if t >= current_time:
                    return t
    return None

def find_route(origin, destination, departure_time_str):
    departure_time = datetime.combine(datetime.today().date(), datetime.strptime(departure_time_str, "%H:%M").time())
    pq = []
    heapq.heappush(pq, (departure_time, origin, []))
    visited = set()

    while pq:
        current_time, current_stop, path = heapq.heappop(pq)
        
        if current_stop == destination:
            return path

        if current_stop in visited:
            continue
        visited.add(current_stop)

        if current_stop not in graph:
            continue

        for (next_stop, line_id, travel_minutes) in graph[current_stop]:
            next_departure = get_next_departure_time(line_id, current_stop, current_time)
            if next_departure is None:
                continue
            arrival_time = next_departure + timedelta(minutes=travel_minutes)

            new_path = path + [{
                "line": line_id,
                "board_stop": current_stop,
                "depart": next_departure.strftime("%H:%M"),
                "alight_stop": next_stop,
                "arrive": arrival_time.strftime("%H:%M")
            }]
            heapq.heappush(pq, (arrival_time, next_stop, new_path))

    return None

@app.route("/")
def index():
    return render_template("base.html")

@app.route("/route")
def route_handler():
    origin = request.args.get("origin")
    destination = request.args.get("destination")
    departure_time = request.args.get("time", "06:00")

    if not origin or not destination:
        return jsonify({"error": "Origin and destination required"}), 400

    path = find_route(origin, destination, departure_time)
    if path is None:
        return jsonify({"error": "No route found"}), 404
    return jsonify({"steps": path})

@app.route("/admin")
def admin_page():
    return render_template("admin.html", current_data=json.dumps(transit_data, indent=2))

@app.route("/update_schedule", methods=["POST"])
def update_schedule():
    global transit_data
    try:
        new_data = request.get_json(force=True)
    except:
        return jsonify({"error": "Invalid JSON"}), 400

    if "lines" not in new_data:
        return jsonify({"error": "Data must contain 'lines'"}), 400

    transit_data = new_data
    build_graph_from_data()
    return jsonify({"status": "Schedule updated successfully"}), 200

@app.route("/lines_data")
def lines_data():
    lines_info = []
    for line in transit_data["lines"]:
        line_stops = []
        for stop in line["stops"]:
            if stop in stop_locations:
                line_stops.append({
                    "name": stop,
                    "lat": stop_locations[stop]["lat"],
                    "lng": stop_locations[stop]["lng"]
                })
        lines_info.append({
            "id": line["id"],
            "name": line["name"],
            "stops": line_stops
        })
    return jsonify({"lines": lines_info})

if __name__ == "__main__":
    app.run(debug=True)
