var map = L.map('map').setView([30.3322, -81.6557], 10);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  maxZoom: 19
}).addTo(map);

function getRoute() {
    const origin = document.getElementById('origin').value;
    const destination = document.getElementById('destination').value;
    const time = document.getElementById('time').value;

    fetch(`/route?origin=${origin}&destination=${destination}&time=${time}`)
        .then(res => res.json())
        .then(data => {
            const stepsDiv = document.getElementById('steps');
            if (data.error) {
                stepsDiv.innerHTML = `<p>${data.error}</p>`;
            } else {
                displaySteps(data.steps);
            }
        })
        .catch(err => {
            console.error(err);
            document.getElementById('steps').innerHTML = "<p>Failed to fetch route.</p>";
        });
}

function displaySteps(steps) {
    let html = '';
    steps.forEach((step, i) => {
        html += `<p><strong>Step ${i+1}:</strong><br>
                 Take ${step.line} from ${step.board_stop} at ${step.depart}<br>
                 Arrive at ${step.alight_stop} at ${step.arrive}</p>`;
    });
    document.getElementById('steps').innerHTML = html;
}

// Draw lines function
function drawLines() {
    fetch('/lines_data')
      .then(response => response.json())
      .then(data => {
          data.lines.forEach(line => {
              const latlngs = line.stops.map(s => [s.lat, s.lng]);
              const polyline = L.polyline(latlngs, {
                  color: getRandomColor(),
                  weight: 4,
                  opacity: 0.7
              }).addTo(map);
              polyline.bindPopup(line.name);

              line.stops.forEach(stop => {
                  const marker = L.marker([stop.lat, stop.lng]).addTo(map);
                  marker.bindPopup(`<strong>${stop.name}</strong><br>${line.name}`);
              });
          });
      })
      .catch(err => console.error("Error fetching lines data:", err));
}

function getRandomColor() {
    const colors = ["blue", "red", "green", "orange", "purple", "magenta", "brown"];
    return colors[Math.floor(Math.random() * colors.length)];
}

document.addEventListener('DOMContentLoaded', drawLines);
