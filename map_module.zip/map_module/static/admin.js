document.getElementById('updateBtn').addEventListener('click', function() {
    const scheduleJSON = document.getElementById('scheduleInput').value;
    let parsedData;
    try {
        parsedData = JSON.parse(scheduleJSON);
    } catch (e) {
        document.getElementById('statusMsg').textContent = "Invalid JSON: " + e.message;
        return;
    }

    fetch('/update_schedule', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(parsedData)
    })
    .then(res => res.json())
    .then(data => {
        if (data.error) {
            document.getElementById('statusMsg').textContent = "Error: " + data.error;
        } else {
            document.getElementById('statusMsg').textContent = data.status;
        }
    })
    .catch(err => {
        document.getElementById('statusMsg').textContent = "Fetch error: " + err;
    });
});
